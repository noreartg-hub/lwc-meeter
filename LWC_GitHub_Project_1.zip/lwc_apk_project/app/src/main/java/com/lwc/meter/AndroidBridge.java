package com.lwc.meter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;

public class AndroidBridge {
    private final Context ctx;
    AndroidBridge(Context ctx) { this.ctx = ctx; }

    @JavascriptInterface
    public String getPlatform() { return "android"; }

    @JavascriptInterface
    public void openWhatsApp(String phone, String msg) {
        String url = "https://wa.me/" + phone + "?text=" + Uri.encode(msg);
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    @JavascriptInterface
    public void shareText(String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, text);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(Intent.createChooser(i, "مشاركة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
}
